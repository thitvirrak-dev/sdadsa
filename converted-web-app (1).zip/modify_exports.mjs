import fs from "node:fs";

const file = "/home/ubuntu/converted-web-app/client/src/pages/Home.tsx";
let source = fs.readFileSync(file, "utf8");

const helpers = `function csvCell(value: unknown) {
  return ` + "`\"${String(value ?? \"\").replaceAll(\"\\\", \"\\\\\").replaceAll(\"\\\"\", \"\\\"\\\"")}\"`" + `;
}

function downloadCsv(filename: string, headers: string[], rows: Array<Array<unknown>>) {
  const csv = [headers, ...rows].map((row) => row.map(csvCell).join(",")).join("\\r\\n");
  const blob = new Blob(["\\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function printSheet(target: "closeout" | "handover", title: string) {
  const className = ` + "`printing-${target}`" + `;
  const previousTitle = document.title;
  document.title = title;
  document.body.classList.add(className);
  const cleanup = () => {
    document.body.classList.remove(className);
    document.title = previousTitle;
  };
  window.addEventListener("afterprint", cleanup, { once: true });
  window.setTimeout(() => window.print(), 40);
}

`;
source = source.replace("function ShiftReportsView", helpers + "function ShiftReportsView");

const shiftStart = source.indexOf("function ShiftReportsView");
const closeoutStart = source.indexOf("function CloseoutView", shiftStart);
if (shiftStart < 0 || closeoutStart < 0) throw new Error("Could not locate shift report boundaries");
const shiftBlock = source.slice(shiftStart, closeoutStart);
const shiftReplacement = `function ShiftReportsView({ language, t }: { language: Language; t: Copy }) {
  const [generated, setGenerated] = useState(false);
  const reportDate = "30 Aug 2026";
  const rows = [
    [reportDate, "Morning", "07:00 – 15:00", "85%", "$950", "Ready"],
    [reportDate, "Afternoon", "15:00 – 23:00", "81%", "$1,080", "Ready"],
    [reportDate, "Night", "23:00 – 07:00", "82%", "$720", "Ready"],
  ];
  const exportHandoverCsv = () => {
    downloadCsv("fdr-shift-handover-2026-08-30.csv", ["Date", "Shift", "Hours", "Occupancy", "Cash close", "Handover status"], rows);
    toast.success(language === "km" ? "ឯកសារ CSV បានទាញយក" : "Handover CSV downloaded");
  };
  return <div className="section-stack"><SectionHeader eyebrow="FDR / SHIFT RHYTHM" title={t.pageShiftReports} description={language === "km" ? "មើលសេចក្តីរាយការណ៍តាមវេន ឬភ្ជាប់វេនទាំងបីជាសន្លឹកតែមួយ។" : "Review individual shifts or join all three into a single operating sheet."} actions={<div className="toolbar-actions"><input className="compact-input" type="date" defaultValue={todayIso()} /><button className="primary-button" onClick={() => setGenerated(true)}><RefreshCcw size={15} />{t.generateReport}</button><button className="secondary-button" onClick={exportHandoverCsv}><Download size={15} />CSV</button><button className="secondary-button" onClick={() => printSheet("handover", "FDR Shift Handover") }><Printer size={15} />PDF</button></div>} />{generated ? <div className="shift-report-output print-handover-sheet"><div className="report-summary-banner"><div><span className="eyebrow">DAILY CLOSE · {reportDate}</span><h3>{language === "km" ? "សេចក្តីសង្ខេបប្រតិបត្តិការប្រចាំថ្ងៃ" : "Daily operating summary"}</h3></div><span className="status-pill approved"><CheckCircle2 size={13} />{language === "km" ? "បានបង្កើត" : "Generated"}</span></div><div className="shift-report-grid">{(["Morning", "Afternoon", "Night"] as Shift[]).map((name, index) => <div className="shift-card" key={name}><div className="shift-card-top"><span className={cn("shift-icon", index === 0 ? "sunrise" : index === 1 ? "sun" : "moon")}>{index === 0 ? <Sunrise size={17} /> : index === 1 ? <Sun size={17} /> : <Moon size={17} />}</span><div><strong>{name} shift</strong><span>{index === 0 ? "07:00 – 15:00" : index === 1 ? "15:00 – 23:00" : "23:00 – 07:00"}</span></div></div><dl><div><dt>Occupancy</dt><dd>{[85, 81, 82][index]}%</dd></div><div><dt>Cash close</dt><dd>${[950, 1080, 720][index].toLocaleString()}</dd></div><div><dt>Handover</dt><dd className="success-text">Ready</dd></div></dl><button className="text-button">Open shift sheet <ArrowUpRight size={13} /></button></div>)}</div></div> : <EmptyState icon={<FileBarChart2 size={24} />} title={language === "km" ? "ជ្រើសរើសកាលបរិច្ឆេទដើម្បីបង្កើតសន្លឹកវេន" : "Choose a date to generate the shift sheet"} detail={language === "km" ? "សន្លឹកនេះនឹងភ្ជាប់ទិន្នន័យពីវេនព្រឹក រសៀល និងយប់។" : "The sheet will connect morning, afternoon, and night data."} />}</div>;
}

`;
source = source.replace(shiftBlock, shiftReplacement);

const newCloseoutStart = source.indexOf("function CloseoutView");
const shiftBlockStart = source.indexOf("function ShiftBlock", newCloseoutStart);
if (newCloseoutStart < 0 || shiftBlockStart < 0) throw new Error("Could not locate closeout boundaries");
const closeoutBlock = source.slice(newCloseoutStart, shiftBlockStart);
const closeoutReplacement = `function CloseoutView({ language, t }: { language: Language; t: Copy }) {
  const [saved, setSaved] = useState(false);
  const [morningClose, setMorningClose] = useState(950);
  const [afternoonOpen, setAfternoonOpen] = useState(950);
  useEffect(() => setAfternoonOpen(morningClose), [morningClose]);
  const exportCloseoutCsv = () => {
    downloadCsv("fdr-daily-closeout-2026-08-30.csv", ["Date", "Shift", "Staff", "Opening float USD", "Closing float USD", "Handover note"], [
      ["30 Aug 2026", "Morning", "John Doe", "200", String(morningClose), "Pending tasks recorded"],
      ["30 Aug 2026", "Afternoon", "Dara Lim", String(afternoonOpen), "1080", "Linked from morning"],
      ["30 Aug 2026", "Night", "Nary Chann", "1080", "720", "End-of-day summary recorded"],
    ]);
    toast.success(language === "km" ? "ឯកសារ CSV បានទាញយក" : "Closeout CSV downloaded");
  };
  return <div className="section-stack"><SectionHeader eyebrow="FDR / THE LAST PAGE" title={t.pageCloseout} description={language === "km" ? "សន្លឹកបិទបញ្ជី និងប្រគល់វេនដែលភ្ជាប់សាច់ប្រាក់ពីវេនមួយទៅវេនបន្ទាប់។" : "A connected closeout and handover sheet that carries cash from one shift into the next."} actions={<div className="toolbar-actions"><button className="secondary-button" onClick={exportCloseoutCsv}><Download size={15} />CSV</button><button className="secondary-button" onClick={() => printSheet("closeout", "FDR Daily Closeout") }><Printer size={15} />PDF</button><button className="primary-button" onClick={() => { setSaved(true); toast.success(t.saved); }}><Save size={15} />{t.save}</button></div>} /><div className="closeout-sheet print-closeout-sheet"><div className="closeout-banner"><div><span className="eyebrow">DAILY FRONT OFFICE CLOSEOUT</span><h3>{language === "km" ? "សន្លឹកបិទបញ្ជី និងផ្ទេរវេនការងារផ្នែកទទួលភ្ញៀវ" : "Daily front office closeout & connected handover"}</h3></div>{saved && <span className="status-pill approved"><CheckCircle2 size={13} />Saved</span>}</div><div className="form-grid two"><Field label={
	t.date + " / Date"}><input type="date" defaultValue={todayIso()} /></Field><Field label={language === "km" ? "ថ្ងៃការងារ" : "Day of week"}><select defaultValue="Sun"><option>Sunday / អាទិត្យ</option><option>Monday / ចន្ទ</option><option>Tuesday / អង្គារ</option></select></Field></div><ShiftBlock title={language === "km" ? "១. របាយការណ៍ប្រតិបត្តិការវេនព្រឹក" : "1. Morning shift report"} tone="morning"><div className="form-grid three"><Field label={language === "km" ? "ឈ្មោះបុគ្គលិក" : "Staff name"}><input defaultValue="John Doe" /></Field><Field label="Opening float · USD"><input type="number" defaultValue="200" /></Field><Field label="Closing float · USD"><input type="number" value={morningClose} onChange={(event) => setMorningClose(Number(event.target.value))} /></Field></div><Field label={language === "km" ? "បញ្ហាដែលនៅសល់" : "Pending tasks"}><textarea rows={2} placeholder={language === "km" ? "កំណត់ចំណាំសម្រាប់វេនរសៀល..." : "Notes for the afternoon shift..."} /></Field></ShiftBlock><ShiftBlock title={language === "km" ? "២. របាយការណ៍ប្រតិបត្តិការវេនរសៀល" : "2. Afternoon shift report"} tone="afternoon"><div className="form-grid three"><Field label={language === "km" ? "ឈ្មោះបុគ្គលិក" : "Staff name"}><input defaultValue="Dara Lim" /></Field><Field label="Opening float · USD"><div className="readonly-value"><strong>${afternoonOpen.toFixed(2)}</strong><span>Linked from morning</span></div></Field><Field label="Closing float · USD"><input type="number" defaultValue="1,080" /></Field></div><div className="form-grid two"><Field label="Check-in average"><input placeholder="minutes" /></Field><Field label={language === "km" ? "បញ្ហាដែលនៅសល់" : "Pending tasks"}><textarea rows={2} /></Field></div></ShiftBlock><ShiftBlock title={language === "km" ? "៣. របាយការណ៍ប្រតិបត្តិការវេនយប់" : "3. Night shift report"} tone="night"><div className="form-grid three"><Field label={language === "km" ? "ឈ្មោះបុគ្គលិក" : "Staff name"}><input defaultValue="Nary Chann" /></Field><Field label="Opening float · USD"><div className="readonly-value"><strong>$1,080.00</strong><span>Linked from afternoon</span></div></Field><Field label="Closing float · USD"><input type="number" defaultValue="720" /></Field></div><Field label={language === "km" ? "សេចក្តីសង្ខេបបិទថ្ងៃ" : "End-of-day summary"}><textarea rows={2} placeholder={language === "km" ? "កត់ត្រាអ្វីដែលវេនព្រឹកត្រូវដឹង..." : "Capture what the morning team should know..."} /></Field></ShiftBlock></div></div>;
}

`;
source = source.replace(closeoutBlock, closeoutReplacement);
fs.writeFileSync(file, source);
